#ifndef BLISS_LIGHTMAP_INCLUDED
#define BLISS_LIGHTMAP_INCLUDED

// Normalized sampling works with both the legacy 16x16 and 26.1 UI 1x1 lightmaps.
// Coordinates follow Minecraft 26.1.2's sample_lightmap.glsl.
vec4 bliss_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    vec2 at = clamp(vec2(uv) / 256.0 + vec2(0.5 / 16.0),
                    vec2(0.5 / 16.0), vec2(15.5 / 16.0));
    return texture(lightMap, at);
}

#endif
